Please unpack the whole package after downloading it from Themeforest.
On that extracted themeforest-virtux-shopify-theme, You can find files like
Documentation,
virtux.zip ,
Log.txt and Readme.txt.

You need to install the file "virtux.zip".


Online documentation link :  https://themessupport.com/dt-shop/virtux/