import {HeaderLogo} from '../../../utils/allImgs'

const Logo = HeaderLogo;

export default Logo