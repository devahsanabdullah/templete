
/////////////////////////////////////////////////////////////////////////////// HomeDemo1
import HomePageDemo1 from "../../assets/img/demos/demo-1.png"
import HomePageDemo2 from "../../assets/img/demos/demo-2.png"
import HomePageDemo3 from "../../assets/img/demos/demo-3.png"

import HomePageDemo4 from "../../assets/img/demos/demo-4.png"
import HomePageDemo5 from "../../assets/img/demos/demo-5.png"
import HomePageDemo6 from "../../assets/img/demos/demo-6.png"

import HomeDemo1Platform1 from "../../assets/img/core-img/platform1.png"
import HomeDemo1About1 from "../../assets/img/core-img/about-1.png"
import HomeDemo1JoinBottom from "../../assets/img/svg/join-bottom.svg"

import HomeDemo1Computer from "../../assets/img/core-img/computer.png"

import HomeDemo1Platforms1 from "../../assets/img/ico-platforms/1.png"
import HomeDemo1Platforms2 from "../../assets/img/ico-platforms/2.png"
import HomeDemo1Platforms3 from "../../assets/img/ico-platforms/3.png"
import HomeDemo1Platforms4 from "../../assets/img/ico-platforms/4.png"
import HomeDemo1Platforms5 from "../../assets/img/ico-platforms/5.png"
import HomeDemo1Platforms6 from "../../assets/img/ico-platforms/6.png"

import HomeDemo1Feature1 from "../../assets/img/features/feature-1.svg"
import HomeDemo1Feature2 from "../../assets/img/features/feature-2.svg"
import HomeDemo1Feature3 from "../../assets/img/features/feature-3.svg"
import HomeDemo1Feature4 from "../../assets/img/features/feature-4.svg"
import HomeDemo1Feature5 from "../../assets/img/features/feature-5.svg"
import HomeDemo1Feature6 from "../../assets/img/features/feature-6.svg"
import HomeDemo1Feature7 from "../../assets/img/features/feature-7.svg"
import HomeDemo1Feature8 from "../../assets/img/features/feature-8.svg"

import HomeDemo1FeaturesS1 from "../../assets/img/features/s1.svg"
import HomeDemo1FeaturesS2 from "../../assets/img/features/s2.svg"
import HomeDemo1FeaturesS3 from "../../assets/img/features/s3.svg"
import HomeDemo1FeaturesS4 from "../../assets/img/features/s4.svg"
import HomeDemo1Platform from "../../assets/img/core-img/platform.png"
import HomeDemo1Rings from "../../assets/img/core-img/rings.png"

import HomeDemo1Wwhitepaper from "../../assets/img/core-img/whitepaper.png"

import HomeDemo1Distribution from "../../assets/img/core-img/distribution.png"
import HomeDemo1Graph11 from "../../assets/img/core-img/graph-11.png"

import HomeDemo1FeaturesF1 from "../../assets/img/features/f1.svg"
import HomeDemo1FeaturesF2 from "../../assets/img/features/f2.svg"
import HomeDemo1FeaturesF3 from "../../assets/img/features/f3.svg"
import HomeDemo1FeaturesF4 from "../../assets/img/features/f4.svg"
import HomeDemo1FeaturesF5 from "../../assets/img/features/f5.svg"
import HomeDemo1FeaturesF6 from "../../assets/img/features/f6.svg"

import HomeDemo1Faq from "../../assets/img/svg/faq.svg"

import HomeDemo1TeamImg1 from "../../assets/img/team-img/1.png"
import HomeDemo1TeamImg2 from "../../assets/img/team-img/2.png"
import HomeDemo1TeamImg3 from "../../assets/img/team-img/3.png"
import HomeDemo1TeamImg4 from "../../assets/img/team-img/4.png"

import HomeDemo1BlogImg1 from "../../assets/img/blog-img/1.jpg"
import HomeDemo1BlogImg2 from "../../assets/img/blog-img/2.jpg"
import HomeDemo1BlogImg3 from "../../assets/img/blog-img/3.jpg"
/////////////////////////////////////////////////////////////////////////////// HomeDemo2

import HomeDemo2IconsH1 from "../../assets/img/icons/h1.png"
import HomeDemo2IconsH11 from "../../assets/img/icons/h11.png"
import HomeDemo2IconsH2 from "../../assets/img/icons/h2.png"
import HomeDemo2IconsH22 from "../../assets/img/icons/h22.png"
import HomeDemo2IconsH3 from "../../assets/img/icons/h3.png"
import HomeDemo2IconsH33 from "../../assets/img/icons/h33.png"

import HomeDemo2Feature1 from "../../assets/img/core-img/feature-1.png"
import HomeDemo2SmallCar from "../../assets/img/core-img/small-car.png"

import HomeDemo2Platform1 from "../../assets/img/core-img/platform1.png"
import HomeDemo2About1 from "../../assets/img/core-img/about-1.png"
import HomeDemo2JoinBottom from "../../assets/img/svg/join-bottom.svg"

import HomeDemo2Computer from "../../assets/img/core-img/computer.png"

import HomeDemo2Platforms1 from "../../assets/img/ico-platforms/1.png"
import HomeDemo2Platforms2 from "../../assets/img/ico-platforms/2.png"
import HomeDemo2Platforms3 from "../../assets/img/ico-platforms/3.png"
import HomeDemo2Platforms4 from "../../assets/img/ico-platforms/4.png"
import HomeDemo2Platforms5 from "../../assets/img/ico-platforms/5.png"
import HomeDemo2Platforms6 from "../../assets/img/ico-platforms/6.png"

import HomeDemo2Feature2 from "../../assets/img/features/feature-2.svg"
import HomeDemo2Feature3 from "../../assets/img/features/feature-3.svg"
import HomeDemo2Feature4 from "../../assets/img/features/feature-4.svg"
import HomeDemo2Feature5 from "../../assets/img/features/feature-5.svg"
import HomeDemo2Feature6 from "../../assets/img/features/feature-6.svg"
import HomeDemo2Feature7 from "../../assets/img/features/feature-7.svg"
import HomeDemo2Feature8 from "../../assets/img/features/feature-8.svg"

import HomeDemo2FeaturesS1 from "../../assets/img/features/s1.svg"
import HomeDemo2FeaturesS2 from "../../assets/img/features/s2.svg"
import HomeDemo2FeaturesS3 from "../../assets/img/features/s3.svg"
import HomeDemo2FeaturesS4 from "../../assets/img/features/s4.svg"
import HomeDemo2Platform from "../../assets/img/core-img/platform.png"
import HomeDemo2Rings from "../../assets/img/core-img/rings.png"

import HomeDemo2Wwhitepaper from "../../assets/img/core-img/whitepaper.png"

import HomeDemo2Distribution from "../../assets/img/core-img/distribution.png"
import HomeDemo2Graph11 from "../../assets/img/core-img/graph-11.png"

import HomeDemo2FeaturesF1 from "../../assets/img/features/f1.svg"
import HomeDemo2FeaturesF2 from "../../assets/img/features/f2.svg"
import HomeDemo2FeaturesF3 from "../../assets/img/features/f3.svg"
import HomeDemo2FeaturesF4 from "../../assets/img/features/f4.svg"
import HomeDemo2FeaturesF5 from "../../assets/img/features/f5.svg"
import HomeDemo2FeaturesF6 from "../../assets/img/features/f6.svg"

import HomeDemo2Faq from "../../assets/img/svg/faq.svg"

import HomeDemo2TeamImg1 from "../../assets/img/team-img/1.png"
import HomeDemo2TeamImg2 from "../../assets/img/team-img/2.png"
import HomeDemo2TeamImg3 from "../../assets/img/team-img/3.png"
import HomeDemo2TeamImg4 from "../../assets/img/team-img/4.png"

import HomeDemo2BlogImg1 from "../../assets/img/blog-img/1.jpg"
import HomeDemo2BlogImg2 from "../../assets/img/blog-img/2.jpg"
import HomeDemo2BlogImg3 from "../../assets/img/blog-img/3.jpg"

/////////////////////////////////////////////////////////////////////////////// HomeDemo3

import HomeDemo3IconsH1 from "../../assets/img/icons/h1.png"
import HomeDemo3IconsH11 from "../../assets/img/icons/h11.png"
import HomeDemo3IconsH2 from "../../assets/img/icons/h2.png"
import HomeDemo3IconsH22 from "../../assets/img/icons/h22.png"
import HomeDemo3IconsH3 from "../../assets/img/icons/h3.png"
import HomeDemo3IconsH33 from "../../assets/img/icons/h33.png"

import HomeDemo3Feature1 from "../../assets/img/core-img/feature-1.png"
import HomeDemo3SmallCar from "../../assets/img/core-img/small-car.png"

import HomeDemo3Platform1 from "../../assets/img/core-img/platform1.png"
import HomeDemo3About1 from "../../assets/img/core-img/about-1.png"
import HomeDemo3JoinBottom from "../../assets/img/svg/join-bottom.svg"

import HomeDemo3Platform from "../../assets/img/core-img/platform.png"
import HomeDemo3Rings from "../../assets/img/core-img/rings.png"

import HomeDemo3Computer from "../../assets/img/core-img/computer.png"

import HomeDemo3Platforms1 from "../../assets/img/ico-platforms/1.png"
import HomeDemo3Platforms2 from "../../assets/img/ico-platforms/2.png"
import HomeDemo3Platforms3 from "../../assets/img/ico-platforms/3.png"
import HomeDemo3Platforms4 from "../../assets/img/ico-platforms/4.png"
import HomeDemo3Platforms5 from "../../assets/img/ico-platforms/5.png"
import HomeDemo3Platforms6 from "../../assets/img/ico-platforms/6.png"

import HomeDemo3Feature2 from "../../assets/img/features/feature-2.svg"
import HomeDemo3Feature3 from "../../assets/img/features/feature-3.svg"
import HomeDemo3Feature4 from "../../assets/img/features/feature-4.svg"
import HomeDemo3Feature5 from "../../assets/img/features/feature-5.svg"
import HomeDemo3Feature6 from "../../assets/img/features/feature-6.svg"
import HomeDemo3Feature7 from "../../assets/img/features/feature-7.svg"
import HomeDemo3Feature8 from "../../assets/img/features/feature-8.svg"

import HomeDemo3FeaturesS1 from "../../assets/img/features/s1.svg"
import HomeDemo3FeaturesS2 from "../../assets/img/features/s2.svg"
import HomeDemo3FeaturesS3 from "../../assets/img/features/s3.svg"
import HomeDemo3FeaturesS4 from "../../assets/img/features/s4.svg"

import HomeDemo3Wwhitepaper from "../../assets/img/core-img/whitepaper.png"

import HomeDemo3Distribution from "../../assets/img/core-img/distribution.png"
import HomeDemo3Graph11 from "../../assets/img/core-img/graph-11.png"

import HomeDemo3FeaturesF1 from "../../assets/img/features/f1.svg"
import HomeDemo3FeaturesF2 from "../../assets/img/features/f2.svg"
import HomeDemo3FeaturesF3 from "../../assets/img/features/f3.svg"
import HomeDemo3FeaturesF4 from "../../assets/img/features/f4.svg"
import HomeDemo3FeaturesF5 from "../../assets/img/features/f5.svg"
import HomeDemo3FeaturesF6 from "../../assets/img/features/f6.svg"

import HomeDemo3Faq from "../../assets/img/svg/faq.svg"

import HomeDemo3TeamImg1 from "../../assets/img/team-img/1.png"
import HomeDemo3TeamImg2 from "../../assets/img/team-img/2.png"
import HomeDemo3TeamImg3 from "../../assets/img/team-img/3.png"
import HomeDemo3TeamImg4 from "../../assets/img/team-img/4.png"

import HomeDemo3BlogImg1 from "../../assets/img/blog-img/1.jpg"
import HomeDemo3BlogImg2 from "../../assets/img/blog-img/2.jpg"
import HomeDemo3BlogImg3 from "../../assets/img/blog-img/3.jpg"

/////////////////////////////////////////////////////////////////////////////// HomeDemo4

import HomeDemo4IconsH1 from "../../assets/img/icons/h1.png"
import HomeDemo4IconsH11 from "../../assets/img/icons/h11.png"
import HomeDemo4IconsH2 from "../../assets/img/icons/h2.png"
import HomeDemo4IconsH22 from "../../assets/img/icons/h22.png"
import HomeDemo4IconsH3 from "../../assets/img/icons/h3.png"
import HomeDemo4IconsH33 from "../../assets/img/icons/h33.png"

// import HomeDemo4Feature1 from "../../assets/img/core-img/feature-1.png"
import HomeDemo4SmallCar from "../../assets/img/core-img/small-car.png"

import HomeDemo4Platform1 from "../../assets/img/core-img/platform1.png"
import HomeDemo4About1 from "../../assets/img/core-img/about-1.png"
import HomeDemo4JoinBottom from "../../assets/img/svg/join-bottom.svg"

import HomeDemo4Computer from "../../assets/img/core-img/computer.png"

import HomeDemo4Platforms1 from "../../assets/img/ico-platforms/1.png"
import HomeDemo4Platforms2 from "../../assets/img/ico-platforms/2.png"
import HomeDemo4Platforms3 from "../../assets/img/ico-platforms/3.png"
import HomeDemo4Platforms4 from "../../assets/img/ico-platforms/4.png"
import HomeDemo4Platforms5 from "../../assets/img/ico-platforms/5.png"
import HomeDemo4Platforms6 from "../../assets/img/ico-platforms/6.png"

import HomeDemo4About3 from "../../assets/img/core-img/about-3.png"

import HomeDemo4FeaturesS1 from "../../assets/img/features/s1.svg"
import HomeDemo4FeaturesS2 from "../../assets/img/features/s2.svg"
import HomeDemo4FeaturesS3 from "../../assets/img/features/s3.svg"
import HomeDemo4FeaturesS4 from "../../assets/img/features/s4.svg"
import HomeDemo4Platform from "../../assets/img/core-img/platform.png"
import HomeDemo4Rings from "../../assets/img/core-img/rings.png"

import HomeDemo4Wwhitepaper from "../../assets/img/core-img/whitepaper.png"

import HomeDemo4Distribution from "../../assets/img/core-img/distribution.png"
import HomeDemo4Graph11 from "../../assets/img/core-img/graph-11.png"

import HomeDemo4FeaturesF1 from "../../assets/img/features/f1.svg"
import HomeDemo4FeaturesF2 from "../../assets/img/features/f2.svg"
import HomeDemo4FeaturesF3 from "../../assets/img/features/f3.svg"
import HomeDemo4FeaturesF4 from "../../assets/img/features/f4.svg"
import HomeDemo4FeaturesF5 from "../../assets/img/features/f5.svg"
import HomeDemo4FeaturesF6 from "../../assets/img/features/f6.svg"

import HomeDemo4Faq from "../../assets/img/svg/faq.svg"

import HomeDemo4TeamImg1 from "../../assets/img/team-img/1.png"
import HomeDemo4TeamImg2 from "../../assets/img/team-img/2.png"
import HomeDemo4TeamImg3 from "../../assets/img/team-img/3.png"
import HomeDemo4TeamImg4 from "../../assets/img/team-img/4.png"

import HomeDemo4BlogImg1 from "../../assets/img/blog-img/1.jpg"
import HomeDemo4BlogImg2 from "../../assets/img/blog-img/2.jpg"
import HomeDemo4BlogImg3 from "../../assets/img/blog-img/3.jpg"

import HomeDemo4Feature1 from "../../assets/img/features/feature-1.svg"
import HomeDemo4Feature2 from "../../assets/img/features/feature-2.svg"
import HomeDemo4Feature3 from "../../assets/img/features/feature-3.svg"
import HomeDemo4Feature4 from "../../assets/img/features/feature-4.svg"
import HomeDemo4Feature5 from "../../assets/img/features/feature-5.svg"
import HomeDemo4Feature6 from "../../assets/img/features/feature-6.svg"
import HomeDemo4Feature7 from "../../assets/img/features/feature-7.svg"
import HomeDemo4Feature8 from "../../assets/img/features/feature-8.svg"

/////////////////////////////////////////////////////////////////////////////// HomeDemo5

import HomeDemo5IconsH1 from "../../assets/img/icons/h1.png"
import HomeDemo5IconsH11 from "../../assets/img/icons/h11.png"
import HomeDemo5IconsH2 from "../../assets/img/icons/h2.png"
import HomeDemo5IconsH22 from "../../assets/img/icons/h22.png"
import HomeDemo5IconsH3 from "../../assets/img/icons/h3.png"
import HomeDemo5IconsH33 from "../../assets/img/icons/h33.png"

// import HomeDemo5Feature1 from "../../assets/img/core-img/feature-1.png"
import HomeDemo5SmallCar from "../../assets/img/core-img/small-car.png"

import HomeDemo5Platform1 from "../../assets/img/core-img/platform1.png"
import HomeDemo5About1 from "../../assets/img/core-img/about-1.png"
import HomeDemo5JoinBottom from "../../assets/img/svg/join-bottom.svg"

import HomeDemo5Computer from "../../assets/img/core-img/computer.png"

import HomeDemo5Platforms1 from "../../assets/img/ico-platforms/1.png"
import HomeDemo5Platforms2 from "../../assets/img/ico-platforms/2.png"
import HomeDemo5Platforms3 from "../../assets/img/ico-platforms/3.png"
import HomeDemo5Platforms4 from "../../assets/img/ico-platforms/4.png"
import HomeDemo5Platforms5 from "../../assets/img/ico-platforms/5.png"
import HomeDemo5Platforms6 from "../../assets/img/ico-platforms/6.png"

import HomeDemo5HeroImg from "../../assets/img/core-img/hero-img.png"

import HomeDemo5FeaturesS1 from "../../assets/img/features/s1.svg"
import HomeDemo5FeaturesS2 from "../../assets/img/features/s2.svg"
import HomeDemo5FeaturesS3 from "../../assets/img/features/s3.svg"
import HomeDemo5FeaturesS4 from "../../assets/img/features/s4.svg"
import HomeDemo5Platform from "../../assets/img/core-img/platform.png"
import HomeDemo5Rings from "../../assets/img/core-img/rings.png"

import HomeDemo5Wwhitepaper from "../../assets/img/core-img/whitepaper.png"

import HomeDemo5Distribution from "../../assets/img/core-img/distribution.png"
import HomeDemo5Graph11 from "../../assets/img/core-img/graph-11.png"

import HomeDemo5FeaturesF1 from "../../assets/img/features/f1.svg"
import HomeDemo5FeaturesF2 from "../../assets/img/features/f2.svg"
import HomeDemo5FeaturesF3 from "../../assets/img/features/f3.svg"
import HomeDemo5FeaturesF4 from "../../assets/img/features/f4.svg"
import HomeDemo5FeaturesF5 from "../../assets/img/features/f5.svg"
import HomeDemo5FeaturesF6 from "../../assets/img/features/f6.svg"

import HomeDemo5Faq from "../../assets/img/svg/faq.svg"

import HomeDemo5TeamImg1 from "../../assets/img/team-img/1.png"
import HomeDemo5TeamImg2 from "../../assets/img/team-img/2.png"
import HomeDemo5TeamImg3 from "../../assets/img/team-img/3.png"
import HomeDemo5TeamImg4 from "../../assets/img/team-img/4.png"

import HomeDemo5BlogImg1 from "../../assets/img/blog-img/1.jpg"
import HomeDemo5BlogImg2 from "../../assets/img/blog-img/2.jpg"
import HomeDemo5BlogImg3 from "../../assets/img/blog-img/3.jpg"

import HomeDemo5Feature1 from "../../assets/img/features/feature-1.svg"
import HomeDemo5Feature2 from "../../assets/img/features/feature-2.svg"
import HomeDemo5Feature3 from "../../assets/img/features/feature-3.svg"
import HomeDemo5Feature4 from "../../assets/img/features/feature-4.svg"
import HomeDemo5Feature5 from "../../assets/img/features/feature-5.svg"
import HomeDemo5Feature6 from "../../assets/img/features/feature-6.svg"
import HomeDemo5Feature7 from "../../assets/img/features/feature-7.svg"
import HomeDemo5Feature8 from "../../assets/img/features/feature-8.svg"


/////////////////////////////////////////////////////////////////////////////// HomeDemo6

import HomeDemo6IconsH1 from "../../assets/img/icons/h1.png"
import HomeDemo6IconsH11 from "../../assets/img/icons/h11.png"
import HomeDemo6IconsH2 from "../../assets/img/icons/h2.png"
import HomeDemo6IconsH22 from "../../assets/img/icons/h22.png"
import HomeDemo6IconsH3 from "../../assets/img/icons/h3.png"
import HomeDemo6IconsH33 from "../../assets/img/icons/h33.png"

// import HomeDemo6Feature1 from "../../assets/img/core-img/feature-1.png"
import HomeDemo6SmallCar from "../../assets/img/core-img/small-car.png"

import HomeDemo6Platform1 from "../../assets/img/core-img/platform1.png"
// import HomeDemo6About1 from "../../assets/img/core-img/about-1.png"
import HomeDemo6JoinBottom from "../../assets/img/svg/join-bottom.svg"

import HomeDemo6Computer from "../../assets/img/core-img/computer.png"

import HomeDemo6Platforms1 from "../../assets/img/ico-platforms/1.png"
import HomeDemo6Platforms2 from "../../assets/img/ico-platforms/2.png"
import HomeDemo6Platforms3 from "../../assets/img/ico-platforms/3.png"
import HomeDemo6Platforms4 from "../../assets/img/ico-platforms/4.png"
import HomeDemo6Platforms5 from "../../assets/img/ico-platforms/5.png"
import HomeDemo6Platforms6 from "../../assets/img/ico-platforms/6.png"
// HomeDemo6About1,

import HomeDemo6About1 from "../../assets/img/core-img/about-1.png"

import HomeDemo6FeaturesS1 from "../../assets/img/features/s1.svg"
import HomeDemo6FeaturesS2 from "../../assets/img/features/s2.svg"
import HomeDemo6FeaturesS3 from "../../assets/img/features/s3.svg"
import HomeDemo6FeaturesS4 from "../../assets/img/features/s4.svg"
import HomeDemo6Platform from "../../assets/img/core-img/platform.png"
import HomeDemo6Rings from "../../assets/img/core-img/rings.png"

import HomeDemo6Wwhitepaper from "../../assets/img/core-img/whitepaper.png"

import HomeDemo6Distribution from "../../assets/img/core-img/distribution.png"
import HomeDemo6Graph11 from "../../assets/img/core-img/graph-11.png"

import HomeDemo6FeaturesF1 from "../../assets/img/features/f1.svg"
import HomeDemo6FeaturesF2 from "../../assets/img/features/f2.svg"
import HomeDemo6FeaturesF3 from "../../assets/img/features/f3.svg"
import HomeDemo6FeaturesF4 from "../../assets/img/features/f4.svg"
import HomeDemo6FeaturesF5 from "../../assets/img/features/f5.svg"
import HomeDemo6FeaturesF6 from "../../assets/img/features/f6.svg"

import HomeDemo6Faq from "../../assets/img/svg/faq.svg"

import HomeDemo6TeamImg1 from "../../assets/img/team-img/1.png"
import HomeDemo6TeamImg2 from "../../assets/img/team-img/2.png"
import HomeDemo6TeamImg3 from "../../assets/img/team-img/3.png"
import HomeDemo6TeamImg4 from "../../assets/img/team-img/4.png"

import HomeDemo6BlogImg1 from "../../assets/img/blog-img/1.jpg"
import HomeDemo6BlogImg2 from "../../assets/img/blog-img/2.jpg"
import HomeDemo6BlogImg3 from "../../assets/img/blog-img/3.jpg"

import HomeDemo6Feature1 from "../../assets/img/features/feature-1.svg"
import HomeDemo6Feature2 from "../../assets/img/features/feature-2.svg"
import HomeDemo6Feature3 from "../../assets/img/features/feature-3.svg"
import HomeDemo6Feature4 from "../../assets/img/features/feature-4.svg"
import HomeDemo6Feature5 from "../../assets/img/features/feature-5.svg"
import HomeDemo6Feature6 from "../../assets/img/features/feature-6.svg"
import HomeDemo6Feature7 from "../../assets/img/features/feature-7.svg"
import HomeDemo6Feature8 from "../../assets/img/features/feature-8.svg"


import HeaderLogo from "../../assets/img/core-img/logo.png"

import FooterLogo from "../../assets/img/core-img/logo.png"

import FooterPattern from "../../assets/img/core-img/pattern.png"

export {

	HomePageDemo1,
	HomePageDemo2,
	HomePageDemo3,
	HomePageDemo4,
	HomePageDemo5,
	HomePageDemo6,
	////////////////////////////////////////////////// HomeDemo1
	HomeDemo1Platform1,
	HomeDemo1About1,
	HomeDemo1JoinBottom,
	HomeDemo1Computer,

	HomeDemo1Platforms1,
	HomeDemo1Platforms2,
	HomeDemo1Platforms3,
	HomeDemo1Platforms4,
	HomeDemo1Platforms5,
	HomeDemo1Platforms6,

	HomeDemo1Feature1,
	HomeDemo1Feature2,
	HomeDemo1Feature3,
	HomeDemo1Feature4,
	HomeDemo1Feature5,
	HomeDemo1Feature6,
	HomeDemo1Feature7,
	HomeDemo1Feature8,

	HomeDemo1FeaturesS1,
	HomeDemo1FeaturesS2,
	HomeDemo1FeaturesS3,
	HomeDemo1FeaturesS4,

	HomeDemo1Platform,
	HomeDemo1Rings,

	HomeDemo1Wwhitepaper,

	HomeDemo1Distribution,
	HomeDemo1Graph11,

	HomeDemo1FeaturesF1,
	HomeDemo1FeaturesF2,
	HomeDemo1FeaturesF3,
	HomeDemo1FeaturesF4,
	HomeDemo1FeaturesF5,
	HomeDemo1FeaturesF6,

	HomeDemo1Faq,

	HomeDemo1TeamImg1,
	HomeDemo1TeamImg2,
	HomeDemo1TeamImg3,
	HomeDemo1TeamImg4,

	HomeDemo1BlogImg1,
	HomeDemo1BlogImg2,
	HomeDemo1BlogImg3,
	////////////////////////////////////////////////// HomeDemo2

	HomeDemo2IconsH1,
	HomeDemo2IconsH11,
	HomeDemo2IconsH2,
	HomeDemo2IconsH22,
	HomeDemo2IconsH3,
	HomeDemo2IconsH33,

	HomeDemo2Feature1,
	HomeDemo2SmallCar,

	HomeDemo2Platform1,
	HomeDemo2About1,
	HomeDemo2JoinBottom,
	HomeDemo2Computer,

	HomeDemo2Platforms1,
	HomeDemo2Platforms2,
	HomeDemo2Platforms3,
	HomeDemo2Platforms4,
	HomeDemo2Platforms5,
	HomeDemo2Platforms6,

	HomeDemo2Feature2,
	HomeDemo2Feature3,
	HomeDemo2Feature4,
	HomeDemo2Feature5,
	HomeDemo2Feature6,
	HomeDemo2Feature7,
	HomeDemo2Feature8,

	HomeDemo2FeaturesS1,
	HomeDemo2FeaturesS2,
	HomeDemo2FeaturesS3,
	HomeDemo2FeaturesS4,

	HomeDemo2Platform,
	HomeDemo2Rings,

	HomeDemo2Wwhitepaper,

	HomeDemo2Distribution,
	HomeDemo2Graph11,

	HomeDemo2FeaturesF1,
	HomeDemo2FeaturesF2,
	HomeDemo2FeaturesF3,
	HomeDemo2FeaturesF4,
	HomeDemo2FeaturesF5,
	HomeDemo2FeaturesF6,

	HomeDemo2Faq,

	HomeDemo2TeamImg1,
	HomeDemo2TeamImg2,
	HomeDemo2TeamImg3,
	HomeDemo2TeamImg4,

	HomeDemo2BlogImg1,
	HomeDemo2BlogImg2,
	HomeDemo2BlogImg3,

	////////////////////////////////////////////////// HomeDemo3

	HomeDemo3IconsH1,
	HomeDemo3IconsH11,
	HomeDemo3IconsH2,
	HomeDemo3IconsH22,
	HomeDemo3IconsH3,
	HomeDemo3IconsH33,

	HomeDemo3Feature1,
	HomeDemo3SmallCar,

	HomeDemo3Platform1,
	HomeDemo3About1,
	HomeDemo3JoinBottom,
	HomeDemo3Computer,

	// HomeDemo3Platform,
	// HomeDemo3Rings,

	HomeDemo3Platforms1,
	HomeDemo3Platforms2,
	HomeDemo3Platforms3,
	HomeDemo3Platforms4,
	HomeDemo3Platforms5,
	HomeDemo3Platforms6,

	HomeDemo3Feature2,
	HomeDemo3Feature3,
	HomeDemo3Feature4,
	HomeDemo3Feature5,
	HomeDemo3Feature6,
	HomeDemo3Feature7,
	HomeDemo3Feature8,

	HomeDemo3FeaturesS1,
	HomeDemo3FeaturesS2,
	HomeDemo3FeaturesS3,
	HomeDemo3FeaturesS4,

	HomeDemo3Platform,
	HomeDemo3Rings,

	HomeDemo3Wwhitepaper,

	HomeDemo3Distribution,
	HomeDemo3Graph11,

	HomeDemo3FeaturesF1,
	HomeDemo3FeaturesF2,
	HomeDemo3FeaturesF3,
	HomeDemo3FeaturesF4,
	HomeDemo3FeaturesF5,
	HomeDemo3FeaturesF6,

	HomeDemo3Faq,

	HomeDemo3TeamImg1,
	HomeDemo3TeamImg2,
	HomeDemo3TeamImg3,
	HomeDemo3TeamImg4,

	HomeDemo3BlogImg1,
	HomeDemo3BlogImg2,
	HomeDemo3BlogImg3,

	////////////////////////////////////////////////// HomeDemo4

	HomeDemo4IconsH1,
	HomeDemo4IconsH11,
	HomeDemo4IconsH2,
	HomeDemo4IconsH22,
	HomeDemo4IconsH3,
	HomeDemo4IconsH33,
	HomeDemo4Feature1,
	HomeDemo4SmallCar,
	HomeDemo4Platform1,
	HomeDemo4About1,
	HomeDemo4JoinBottom,
	HomeDemo4Computer,
	HomeDemo4Platforms1,
	HomeDemo4Platforms2,
	HomeDemo4Platforms3,
	HomeDemo4Platforms4,
	HomeDemo4Platforms5,
	HomeDemo4Platforms6,
	HomeDemo4About3,
	HomeDemo4Feature2,
	HomeDemo4Feature3,
	HomeDemo4Feature4,
	HomeDemo4Feature5,
	HomeDemo4Feature6,
	HomeDemo4Feature7,
	HomeDemo4Feature8,
	HomeDemo4FeaturesS1,
	HomeDemo4FeaturesS2,
	HomeDemo4FeaturesS3,
	HomeDemo4FeaturesS4,
	HomeDemo4Platform,
	HomeDemo4Rings,
	HomeDemo4Wwhitepaper,
	HomeDemo4Distribution,
	HomeDemo4Graph11,
	HomeDemo4FeaturesF1,
	HomeDemo4FeaturesF2,
	HomeDemo4FeaturesF3,
	HomeDemo4FeaturesF4,
	HomeDemo4FeaturesF5,
	HomeDemo4FeaturesF6,
	HomeDemo4Faq,
	HomeDemo4TeamImg1,
	HomeDemo4TeamImg2,
	HomeDemo4TeamImg3,
	HomeDemo4TeamImg4,
	HomeDemo4BlogImg1,
	HomeDemo4BlogImg2,
	HomeDemo4BlogImg3,

	////////////////////////////////////////////////// HomeDemo5

	HomeDemo5IconsH1,
	HomeDemo5IconsH11,
	HomeDemo5IconsH2,
	HomeDemo5IconsH22,
	HomeDemo5IconsH3,
	HomeDemo5IconsH33,
	HomeDemo5Feature1,
	HomeDemo5SmallCar,
	HomeDemo5Platform1,
	HomeDemo5About1,
	HomeDemo5JoinBottom,
	HomeDemo5Computer,
	HomeDemo5Platforms1,
	HomeDemo5Platforms2,
	HomeDemo5Platforms3,
	HomeDemo5Platforms4,
	HomeDemo5Platforms5,
	HomeDemo5Platforms6,
	HomeDemo5HeroImg,
	HomeDemo5Feature2,
	HomeDemo5Feature3,
	HomeDemo5Feature4,
	HomeDemo5Feature5,
	HomeDemo5Feature6,
	HomeDemo5Feature7,
	HomeDemo5Feature8,
	HomeDemo5FeaturesS1,
	HomeDemo5FeaturesS2,
	HomeDemo5FeaturesS3,
	HomeDemo5FeaturesS4,
	HomeDemo5Platform,
	HomeDemo5Rings,
	HomeDemo5Wwhitepaper,
	HomeDemo5Distribution,
	HomeDemo5Graph11,
	HomeDemo5FeaturesF1,
	HomeDemo5FeaturesF2,
	HomeDemo5FeaturesF3,
	HomeDemo5FeaturesF4,
	HomeDemo5FeaturesF5,
	HomeDemo5FeaturesF6,
	HomeDemo5Faq,
	HomeDemo5TeamImg1,
	HomeDemo5TeamImg2,
	HomeDemo5TeamImg3,
	HomeDemo5TeamImg4,
	HomeDemo5BlogImg1,
	HomeDemo5BlogImg2,
	HomeDemo5BlogImg3,

	////////////////////////////////////////////////// HomeDemo6

	HomeDemo6IconsH1,
	HomeDemo6IconsH11,
	HomeDemo6IconsH2,
	HomeDemo6IconsH22,
	HomeDemo6IconsH3,
	HomeDemo6IconsH33,
	HomeDemo6Feature1,
	HomeDemo6SmallCar,
	HomeDemo6Platform1,
	HomeDemo6About1,
	HomeDemo6JoinBottom,
	HomeDemo6Computer,
	HomeDemo6Platforms1,
	HomeDemo6Platforms2,
	HomeDemo6Platforms3,
	HomeDemo6Platforms4,
	HomeDemo6Platforms5,
	HomeDemo6Platforms6,
	HomeDemo6Feature2,
	HomeDemo6Feature3,
	HomeDemo6Feature4,
	HomeDemo6Feature5,
	HomeDemo6Feature6,
	HomeDemo6Feature7,
	HomeDemo6Feature8,
	HomeDemo6FeaturesS1,
	HomeDemo6FeaturesS2,
	HomeDemo6FeaturesS3,
	HomeDemo6FeaturesS4,
	HomeDemo6Platform,
	HomeDemo6Rings,
	HomeDemo6Wwhitepaper,
	HomeDemo6Distribution,
	HomeDemo6Graph11,
	HomeDemo6FeaturesF1,
	HomeDemo6FeaturesF2,
	HomeDemo6FeaturesF3,
	HomeDemo6FeaturesF4,
	HomeDemo6FeaturesF5,
	HomeDemo6FeaturesF6,
	HomeDemo6Faq,
	HomeDemo6TeamImg1,
	HomeDemo6TeamImg2,
	HomeDemo6TeamImg3,
	HomeDemo6TeamImg4,
	HomeDemo6BlogImg1,
	HomeDemo6BlogImg2,
	HomeDemo6BlogImg3,

	HeaderLogo,
	FooterLogo,
	FooterPattern
}