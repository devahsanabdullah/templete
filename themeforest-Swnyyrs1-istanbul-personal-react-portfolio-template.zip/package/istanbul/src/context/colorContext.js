import { createContext } from "react";
const ColorContext = createContext();
export default ColorContext;
